import random
from bitarray import bitarray 
from numpy.random import Generator, MT19937, SeedSequence
import random

#a = int.from_bytes(rg.bytes(1),"big") % n

def cambia(b):
    if(b == 0):
        return 1
    else:
        return 0



def GeneradorErrores(bits,n,e, seed):
    sg = SeedSequence(seed)
    rg = Generator(MT19937(sg))
    bits = bitarray(bits)
    bi = int.from_bytes(rg.bytes(1),"big") % (len(bits)-n)
    #print("bi: ", bi)
    #print("n: ", n)
    rafaga = []
    for i in range(e):
        rafaga.append(int.from_bytes(rg.bytes(1),"big") % n)
        
    rafaga = sorted(rafaga)

    #print(rafaga)

    x = 0
    while(x<e):
        bits[bi+rafaga[x]] = cambia(bits[bi+rafaga[x]])
     #   print("bi+rafaga[x]", bi+rafaga[x] ," :", bits[bi+rafaga[x]])
        x = x+1




    return bits

