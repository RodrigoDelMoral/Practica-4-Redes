class Validador:

    def __init__(self) -> None:
        self.numPruebas = 0
        self.exitos = 0
        self.errores = 0

    def esValido(self,bytes):
        self.numPruebas +=1
        for a in bytes:
            if a != 0:
                self.errores +=1
                return False
        self.exitos += 1
        return True

    def imprimirDatosFinales(self):
        print("Total: " + str(self.errores + self.exitos))
        print("Mensajes exitosos " + str(self.exitos))
        print("Total Errores Dectados: "  + str(self.errores))
        print("Probabilidad: " + str(self.errores / 1000))
        #print("Porcentaje exito: " + str((self.exitos/(self.exitos + self.errores))*100))
        #Que no se detecten errores no quiere decir que no esten ahí
