from crc import cyclic_redundancy_check
from codificarArchivo import codificarArchivo
from decode2 import decodificar
from validador import Validador
from ModuloGeneraError import cambia
from ModuloGeneraError import GeneradorErrores

#En las fórmulas de arriba, n es el tamaño de la ráfaga y r es el número de bits de redundancia.

validador = Validador()
n = 4
e = 4
#seed = 10
archivo = "prueba.txt"
#CODIFICACION DEL TEXTO Y CRC
crc = cyclic_redundancy_check(archivo, '11111', 4)
print(crc)

arcodi = codificarArchivo(archivo) + crc
print(arcodi)

#TODO - AGEGRAR ERRORES, MODIFICAR ARCODI
for i in range(1000):
	aux = arcodi
	aux = GeneradorErrores(aux, n, e, i)

	#DESCODIFICACION DEL TEXTO Y CRC
	crc2 = decodificar(aux,"11111",4)
	print(crc2)
	#VALIDAR CON EL VALIDADOR
	validador.esValido(crc2)





validador.imprimirDatosFinales()
