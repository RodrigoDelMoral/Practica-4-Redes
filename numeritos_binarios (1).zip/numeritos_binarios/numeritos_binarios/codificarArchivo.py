
from numpy.random import Generator, MT19937, SeedSequence
sg = SeedSequence(6)
rg = Generator(MT19937(sg))
a = int.from_bytes(rg.bytes(1),"big") % 3
print(a)
from bitarray import bitarray
import numpy as np

def codificarArchivo(archivo):
    b = bitarray()
    texto = ''
    with open(archivo,"r") as file:
        texto = file.read()
    b.frombytes(bytes(texto,'ascii'))
    return b
